//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//---------------------3-1,Swift 2.0运算符之基础运算符-------------------
//赋值运算符
var a = 3
a = 2
var b = 5


//数学运算符

var  x = 10
var y = 3
var z = 0

x + y
x - y
x * y
x / y
x % y

Double (x) / Double(y)
//除法和求操作,除数不能为零 x/y ❌ x%y ❌
//swift中求余操作不仅可以作用于整型中也可作用于小数此处与C  C++不同
let u = 2.5
let v = 1.2
//u%v
//我的求余操作怎么不能用于小数 ❓

//单目运算符,单目运算符符号和后面所接的变量之间不能有空格
var xx = +a
var yy = -u

//为什么我的不能a++  ++a ❓
//a++
//++a

//  a += 2       a = a + 2
a += 2


//----------------------3-2,Swift2.0 运算符之比较运算符,逻辑运算符和判断语句----------------------------
/*
比较运算符 ( 都会返回一个布尔值)

 a == b
 a != b
 a >  b
 a >= b
 a <  b
 a <= b

 a === b
 a !== b
 
 逻辑运算符
 
 !a
 a && b
 a || b

 */

let money = 100
let price = 70

if money > price {
    print("buy it")
}


let capacity = 30
let volume = 50

if money >= price && capacity >= volume {
    print("buy it")
}


if money < price || capacity < volume
{
    print("Can not buy it")
}


if !(money >= price && capacity >= volume) {
    print("Can not buy it")
}

var  isUsernameOK = false
var  isPasswordOK = false
var  isPhoneNumberOK = true
var  isPhoneCodeOK = false

// && 运算优先级 大于 ||
if isUsernameOK && isPasswordOK || isPhoneNumberOK && isPhoneCodeOK {
    print("Login success")
}
else
{
    print("Login failed")
}


//-------------------3-3 Swift 2.0 运算符之三目运算符与变量初始化----------------------------

/*三目运算符
 quester? answer1:answer2
 
  */
var battery = 18

// 此处也可为 let,但只能赋值一次
var batteryColor: UIColor

//必须在赋初值之后变量才可使用,因此  print(batteryColor) ❌

if battery <= 20 {
    batteryColor = UIColor.red
}
else
{
    batteryColor = UIColor.green
}

 var batteryColor2 = battery >= 20 ? UIColor.green :  UIColor.red


// -------------------------------------3-4, Swift2.0 运算符之范围运算符和for-in----------------------------------------

/*
 区间运算符
 闭区间运算符
 [a,b] a...b
 [a,b)  a..<b
 
 */

// 循环体里面虽然只有一行代码也需要用花括号括起来,此处与C语言C++不同
for index in 1...10{
    
    index
    
}


for index in 0..<10
{
    index
}

let courses = ["1111111111","22222222","333333333","444444444"]

for i in 0..<courses.count
{
    print(courses[i])
}

/*
 更高级运算符
 */





























































